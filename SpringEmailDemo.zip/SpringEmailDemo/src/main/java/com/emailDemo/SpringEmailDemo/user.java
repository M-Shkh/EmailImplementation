package com.emailDemo.SpringEmailDemo;

public class user {

	private String to;
	private    String sub;
	   private   String body;
   public user(String to, String sub, String body) {
		super();
		this.to = to;
		this.sub = sub;
		this.body = body;
	}

	
	
}
