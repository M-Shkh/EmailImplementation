package com.emailDemo.SpringEmailDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Repository;


@Repository
public class senderService {
	
	@Autowired
	 private JavaMailSender mail;
	
	public void sendEmail(String to, String sub, String body){
		System.out.println("i am in");
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom("maseerashaikh8236@gmail.com");
		String toEmail = to;
		message.setTo(toEmail);
		String text = "hello world,what are you upto?...........";
		message.setText(text);
		String subject = sub;
		message.setSubject(subject);
	//	JavaMailSender mail = null;
		mail.send(message);
	}
	



	
	
}
