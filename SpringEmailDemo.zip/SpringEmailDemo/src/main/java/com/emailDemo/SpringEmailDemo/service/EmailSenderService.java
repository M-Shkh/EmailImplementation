package com.emailDemo.SpringEmailDemo.service;

public class EmailSenderService {

    public void sendMail(){


    }

    public void sendEmail() {
        String to;
        String from;
        String sub;
        String body;

    }
}

