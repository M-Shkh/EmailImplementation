package com.emailDemo.SpringEmailDemo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;



@SpringBootApplication
public class SpringEmailDemoApplication {

	@Autowired
	private senderService ems;
	

	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringEmailDemoApplication.class, args);
	System.out.println("hello please start the email");
	
	
//	SpringEmailDemoApplication dd=new SpringEmailDemoApplication();
//	dd.sendMail();
	
	}
	
  @Bean
   	public senderService sendMail(){
		System.out.println(" in sendmail");
		System.out.println(ems);
		ems.sendEmail("smaseera86@gmail.com", "configuration setting", "hello, what are you upto?");
		return null;
	}
}
