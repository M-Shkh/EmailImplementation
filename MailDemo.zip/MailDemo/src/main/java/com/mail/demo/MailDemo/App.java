package com.mail.demo.MailDemo;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class App 
{
    public static void main( String[] args ) throws MessagingException
    {
        System.out.println( "preparaing to send message" );
        
        //create message,sub,to and from to send message
        String message="hello dear this is message for security check";
        String subject="Confirmation mail";
        String to="smaseera86@gmail.com";
        String from="maseerashaikh8236@gmail.com";
  
        
        //send the message using the method below
        sendEmail(message,subject,to, from);
    }
    

	private static void sendEmail(String message, String subject, String to, String from) throws MessagingException {
		//this method is responsible to send email and consist of following properties, host
		
		//variable for gmail host
		String host="smtp.gmail.com";   //to send mess from server
		
		
		//get the system properties
		Properties property =System.getProperties();
		System.out.println("Properties:" +property);
		
		//setting info to property(obj)
		//setting host
		property.put("mail.smtp.host",host);  //key-val pair 
		property.put("mail.smtp.port","465");  //port for gmail is ssl-465, tls-587
		property.put("mail.smtp.ssl.enable","true");   //security
		property.put("mail.smtp.auth","true");  //authentication
		
		
		//step 1: to get the session object
		
	Session session=Session.getInstance(property, new Authenticator(){

			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				// TODO Auto-generated method stub
				
				
				return new PasswordAuthentication("maseerashaikh8236@gmail.com","ilrgduczhsnnkonj");
			}
			
		});
	session.setDebug(true);
	
	//Step 2: compose the message(text,media)
	
	MimeMessage m= new MimeMessage(session);
	
	
	//setting from(email sender)
	m.setFrom(from);
	
	
	//adding receipient (to)
	m.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
	
	//adding subject for message
	m.setSubject(subject);
	
	//adding text to message
	m.setText(message);
	
	//Step 3: send the message using send()
	Transport.send(m);
	
	System.out.println("Message sent successfully...");
	
		
	}
}
